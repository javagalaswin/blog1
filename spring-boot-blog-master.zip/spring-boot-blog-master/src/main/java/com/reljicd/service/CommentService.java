package com.reljicd.service;

import com.reljicd.model.Comment;

public interface CommentService {

    Comment save(Comment comment);
}
